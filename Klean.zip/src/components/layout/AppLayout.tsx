import { Outlet } from 'react-router-dom'
import { Sidebar } from './Sidebar'
import { TopBar } from './TopBar'
import { MobileNav } from './MobileNav'

export function AppLayout() {
  return (
    <div className="flex min-h-screen bg-dark-900">
      <Sidebar />
      <div className="flex-1 flex flex-col min-h-screen md:ml-20 lg:ml-24">
        <TopBar />
        <main className="flex-1 p-4 md:p-6 lg:p-8 pb-24 md:pb-8">
          <Outlet />
        </main>
      </div>
      <MobileNav />
    </div>
  )
}

function MobileNav() {
  import { NavLink } from 'react-router-dom'
  import { Home, UtensilsCrossed, Clock, User } from 'lucide-react'

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-dark-800 border-t border-dark-600 flex md:hidden z-50">
      {[
        { to: '/', icon: Home, label: 'Home' },
        { to: '/menu', icon: UtensilsCrossed, label: 'Menu' },
        { to: '/orders', icon: Clock, label: 'History' },
        { to: '/profile', icon: User, label: 'Profile' },
      ].map(({ to, icon: Icon, label }) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/'}
          className={({ isActive }) =>
            `flex-1 flex flex-col items-center py-3 gap-1 text-xs transition-colors ${
              isActive ? 'text-brand-green' : 'text-gray-500'
            }`
          }
        >
          <Icon size={20} />
          <span>{label}</span>
        </NavLink>
      ))}
    </nav>
  )
}